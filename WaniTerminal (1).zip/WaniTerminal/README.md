# Wani Terminal

Android app jo Debian rootfs download karke `proot` ke zariye Linux shell chalati hai.

## Setup se pehle zaroori cheezein

1. **proot binaries (arm64):** Inhe `app/src/main/jniLibs/arm64-v8a/` mein rakhein:
   - `libproot.so` (proot binary)
   - `libprootloader.so` (proot ka loader, optional lekin behtar)

   Ya GitHub repo variables `PROOT_URL` / `PROOT_LOADER_URL` mein direct download links dein, workflow khud download kar legi.
2. **Rootfs:** Apna arm64 Debian `.tar.xz` host karein aur uska SHA-256 nikalein: `sha256sum debian-arm64.tar.xz`
3. `ROOTFS_URL` aur `ROOTFS_SHA256` bharein, ya to `Config.kt` mein, ya GitHub mein **Settings > Secrets and variables > Actions > Variables** mein (workflow build ke waqt Config.kt mein daal deti hai).

## Build

GitHub par push karein. `.github/workflows/build.yml` APK banayegi, Actions ke Artifacts mein `app-debug` milega.

Local build (JDK 17 + Android SDK):
```
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Features

- Asli PTY (rootfs ke `script` ke zariye): colors, Tab completion, history (↑/↓), Ctrl+C / Ctrl+D, `top` waghera
- ANSI colors, bold, underline render hote hain
- Setup screen par download progress, extract count, apt output
- Notification mein Exit button, Copy / Paste / Clear / Restart menu

## Limitations

- Full-screen programs (`vim`, `nano`, `htop`) theek nahi chalenge: cursor movement ka emulator nahi hai.
- Terminal ka size shell shuru hone par fix hota hai (rotate karne par restart karein).
- **targetSdk 28:** Android 10+ par app data se binary chalane ke liye. Play Store par nahi chalegi, sirf APK sideload.
- Kuch phones `proot` ko /proc ya /sys bind karne nahi dete.
