package com.wani.terminal

object Config {
    /** Apna hosted arm64 Debian rootfs (.tar.xz) ka URL yahan dalein (ya GitHub repo variable ROOTFS_URL mein). */
    const val ROOTFS_URL = "https://example.com/rootfs/debian-arm64.tar.xz"

    /** Us file ka SHA-256 (64 hex characters). Jab tak ye placeholder hai, install nahi hoga. */
    const val ROOTFS_SHA256 = "0000000000000000000000000000000000000000000000000000000000000000"

    const val ROOTFS_DIR_NAME = "rootfs"
    const val SHELL = "/bin/bash"
    const val MAX_TEXT_CHARS = 60_000
}
