# Wani Terminal

Android app jo Debian rootfs download karke `proot` ke zariye Linux shell chalati hai.

## Setup se pehle zaroori cheezein

1. **proot binaries (arm64, static):** Inhe `app/src/main/jniLibs/arm64-v8a/` mein rakhein:
   - `libproot.so` (proot binary)
   - `libprootloader.so` (proot ka loader binary)
   Termux mein ye files `pkg install proot` ke baad milti hain (loader aam tor par `$PREFIX/libexec/proot/loader` mein hota hai). Dono files ko upar diye naam (libproot.so, libprootloader.so) se rename karke arm64-v8a folder mein rakhein.
2. **Rootfs:** Apna arm64 Debian `.tar.xz` host karein. Uska SHA-256 nikalein:
   `sha256sum debian-arm64.tar.xz`
3. **Config.kt** mein `ROOTFS_URL` aur `ROOTFS_SHA256` bharein.

## Build

Cloud build (sab se aasan): code GitHub par push karein. `.github/workflows/build.yml` APK banayegi, aur Actions ke Artifacts mein `app-debug` milega.

Local build (PC par, JDK 17 aur Android SDK ke saath):
```
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Pehli dafa chalana

1. App khulne par **Install karein** dabayein.
2. Download, checksum, extract, aur `apt-get update` dikhai denge.
3. Setup complete hone par terminal khulega. Phone par tap karke type karein.

## Limitations (jaan kar)

- **PTY nahi hai:** Colors, `vim`/`nano` jaise full-screen programs, aur arrow keys theek kaam nahi karenge. Ye agla bada kaam hai, Termux ki `terminal-emulator` library use karke.
- **Ctrl+C:** Bina PTY ke signal nahi bheja ja sakta, is liye Ctrl+C shell ko restart karta hai.
- **targetSdk 28:** Android 10+ par app data se binary chalane ki restriction se bachne ke liye. Isi wajah se ye app Play Store par nahi chalegi, sirf APK sideload hogi.
- **Device restrictions:** Kuch phones ya Android versions `proot` ko /proc ya /sys bind karne nahi dete.

## GitHub Actions

- Har push par `.github/workflows/build.yml` APK banati hai. Output **Actions > (run) > Artifacts > wani-terminal-debug** mein milta hai.
- `v1.0.0` jaisa tag push karne par APK GitHub Release mein bhi upload hoti hai.
- Build fail ho to Actions ka log khol kar pehla `error:` wali line copy karke bhejein.
