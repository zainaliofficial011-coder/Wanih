package com.wani.terminal

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedWriter
import java.io.IOException
import java.io.OutputStreamWriter

/**
 * Proot ke andar bash chalata hai. PTY nahi hai, isliye input/output pipes ke zariye hota hai.
 * Ctrl+C ka matlab shell ko restart karna hai.
 */
class ShellSession(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writeLock = Mutex()

    private var process: Process? = null
    @Volatile private var writer: BufferedWriter? = null

    private val _text = MutableStateFlow("")
    val text: StateFlow<String> = _text.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    /** Shell chalu karta hai. Agar pehle se chal raha ho to kuch nahi karta. */
    fun ensureRunning() {
        scope.launch { startInternal() }
    }

    fun restart() {
        scope.launch {
            stopInternal()
            startInternal()
        }
    }

    fun interrupt() {
        appendText("\n^C\n")
        restart()
    }

    fun clear() {
        _text.value = ""
    }

    fun send(line: String) {
        scope.launch {
            writeLock.withLock {
                val w = writer
                if (w == null) {
                    appendText("\n[shell is not running. Tap Restart]\n")
                } else {
                    try {
                        w.write(line)
                        w.flush()
                    } catch (e: IOException) {
                        appendText("\n[write failed: ${e.message}]\n")
                    }
                }
            }
        }
    }

    fun shutdown() {
        scope.launch { stopInternal() }
    }

    @Synchronized
    private fun startInternal() {
        if (process?.isAlive == true) return

        val proot = ProotRunner.prootBinary(context)
        if (!proot.exists()) {
            appendText("[libproot.so not found: ${proot.absolutePath}]\n")
            return
        }

        val p = try {
            ProotRunner.builder(context, listOf(Config.SHELL, "-i")).start()
        } catch (e: IOException) {
            appendText("[shell failed to start: ${e.message}]\n")
            return
        }

        if (_text.value.isEmpty()) appendText(BANNER)
        process = p
        writer = BufferedWriter(OutputStreamWriter(p.outputStream, Charsets.UTF_8))
        _running.value = true
        scope.launch { readOutput(p) }
        scope.launch { watchExit(p) }
    }

    @Synchronized
    private fun stopInternal() {
        try {
            writer?.close()
        } catch (_: IOException) {
            // band karte waqt error ignore
        }
        process?.destroy()
        process = null
        writer = null
        _running.value = false
    }

    private fun readOutput(p: Process) {
        val reader = p.inputStream.bufferedReader(Charsets.UTF_8)
        val buf = CharArray(4096)
        try {
            while (true) {
                val n = reader.read(buf)
                if (n < 0) break
                appendText(String(buf, 0, n))
            }
        } catch (e: IOException) {
            appendText("\n[read error: ${e.message}]\n")
        }
    }

    private fun watchExit(p: Process) {
        val code = try {
            p.waitFor()
        } catch (e: InterruptedException) {
            -1
        }
        synchronized(this) {
            if (process === p) {
                process = null
                writer = null
                _running.value = false
            }
        }
        appendText("\n[shell exited (exit code $code)]\n")
    }

    private fun appendText(chunk: String) {
        val clean = chunk.replace("\r", "").replace(ANSI, "")
        _text.update { old ->
            val next = old + clean
            if (next.length > Config.MAX_TEXT_CHARS) {
                next.substring(next.length - Config.MAX_TEXT_CHARS)
            } else {
                next
            }
        }
    }

    companion object {
        private val ANSI = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

        private val BANNER = """
 __        ___    _   _ ___
 \ \      / / \  | \ | |_ _|
  \ \ /\ / / _ \ |  \| || |
   \ V  V / ___ \| |\  || |
    \_/\_/_/   \_\_| \_|___|

Welcome to Wani Terminal by Mecotina

Type a command and press Enter.

""".trimIndent() + "\n"
    }
}
