package com.wani.terminal

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

private val WaniGreen = Color(0xFF5EE0A8)
private val WaniPurple = Color(0xFF6D5BD0)

fun startTerminalService(context: Context) {
    ContextCompat.startForegroundService(context, Intent(context, TerminalService::class.java))
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as WaniApp
    val setup by app.rootfs.state.collectAsState()
    val ready = setup == SetupState.Ready

    // First open: setup starts automatically, no button press needed
    LaunchedEffect(Unit) {
        if (app.rootfs.state.value == SetupState.NotInstalled) {
            app.appScope.launch { app.rootfs.install() }
        }
    }

    LaunchedEffect(ready) {
        if (ready) startTerminalService(ctx)
    }

    if (ready) {
        TerminalScreen(app.shell)
    } else {
        SetupScreen(setup) {
            app.appScope.launch { app.rootfs.install() }
        }
    }
}

@Composable
fun SetupScreen(state: SetupState, onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Bootstrap package setup",
                color = Color.Black,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(24.dp))
            if (state is SetupState.Error) {
                Text(
                    "Setup failed: ${state.message}",
                    color = Color(0xFFB00020),
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = onRetry) {
                    Text("Retry")
                }
            } else {
                CircularProgressIndicator(color = WaniPurple)
            }
        }
    }
}

@Composable
fun TerminalScreen(shell: ShellSession) {
    val text by shell.text.collectAsState()
    val running by shell.running.collectAsState()
    var input by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    val ctx = LocalContext.current

    LaunchedEffect(text) {
        scroll.scrollTo(scroll.maxValue)
    }

    fun submit() {
        val line = input
        input = ""
        shell.send(line + "\n")
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Wani by Mecotina",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                if (running) "running" else "stopped",
                color = if (running) WaniGreen else Color(0xFFE0AF68),
                fontSize = 12.sp
            )
        }

        Text(
            text = text,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF111217))
                .verticalScroll(scroll)
                .padding(8.dp),
            color = Color(0xFFD7DAE3),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp
        )

        KeysRow(
            running = running,
            onInsert = { input += it },
            onBackspace = { input = input.dropLast(1) },
            onCtrlC = { shell.interrupt() },
            onClear = { shell.clear() },
            onRestart = {
                startTerminalService(ctx)
                shell.restart()
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Type a command") },
                textStyle = TextStyle(fontFamily = FontFamily.Monospace),
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { submit() }) {
                Text("Send")
            }
        }
    }
}

@Composable
fun KeysRow(
    running: Boolean,
    onInsert: (String) -> Unit,
    onBackspace: () -> Unit,
    onCtrlC: () -> Unit,
    onClear: () -> Unit,
    onRestart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        KeyBtn("Tab") { onInsert("  ") }
        KeyBtn("⌫") { onBackspace() }
        KeyBtn("Ctrl+C") { onCtrlC() }
        KeyBtn("Ctrl+L") { onClear() }
        if (!running) {
            KeyBtn("Restart") { onRestart() }
        }
        listOf(
            "|", "~", "/", "-", "_", "*", "&", "\$", "'", "\"", ";", ":",
            "\\", "<", ">", "!", "?", "#", "@", "%", "=", "+", "(", ")",
            "[", "]", "{", "}"
        ).forEach { ch ->
            KeyBtn(ch) { onInsert(ch) }
        }
    }
}

@Composable
fun KeyBtn(label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, fontFamily = FontFamily.Monospace)
    }
}
