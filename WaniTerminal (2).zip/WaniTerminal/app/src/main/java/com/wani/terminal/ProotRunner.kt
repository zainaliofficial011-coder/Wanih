package com.wani.terminal

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object ProotRunner {

    fun prootBinary(context: Context): File =
        File(context.applicationInfo.nativeLibraryDir, "libproot.so")

    /** Rootfs ke andar command chalane ke liye ProcessBuilder banata hai. */
    fun builder(context: Context, args: List<String>): ProcessBuilder {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        val rootfs = File(context.filesDir, Config.ROOTFS_DIR_NAME)
        val tmp = File(context.filesDir, "proot-tmp").apply { mkdirs() }

        val cmd = mutableListOf(
            prootBinary(context).absolutePath,
            "--link2symlink",
            "-0",
            "-r", rootfs.absolutePath,
            "-b", "/dev",
            "-b", "/proc",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root",
            "TERM=dumb",
            "LANG=C.UTF-8",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        cmd.addAll(args)

        return ProcessBuilder(cmd).apply {
            redirectErrorStream(true)
            environment()["PROOT_LOADER"] = File(nativeDir, "libprootloader.so").absolutePath
            environment()["PROOT_TMP_DIR"] = tmp.absolutePath
        }
    }

    /** Ek command chalata hai, har output line par callback deta hai, aur exit code return karta hai. */
    suspend fun runOnce(context: Context, args: List<String>, onLine: (String) -> Unit): Int =
        withContext(Dispatchers.IO) {
            val process = builder(context, args).start()
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach(onLine)
            }
            process.waitFor()
        }
}
